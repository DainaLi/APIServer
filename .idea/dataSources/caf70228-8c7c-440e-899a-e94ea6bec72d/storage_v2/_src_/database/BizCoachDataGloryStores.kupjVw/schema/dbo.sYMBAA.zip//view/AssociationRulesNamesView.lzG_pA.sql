CREATE VIEW [dbo].[AssociationRulesNamesView]
                AS
                SELECT        a.lhs, a.rhs, a.support, a.confidence, a.lift, a.rules_created_on, a.rules_id, a.[Outlet Name], a.models_id, a.rules_active, a.count, b.ItemName AS LeftItemName, b.Description AS LeftDescription, 
                         c.ItemName AS RightItemName, c.Description AS RightDescription
                FROM            dbo.AssociationRules AS a INNER JOIN
                         dbo.ItemDetails AS b ON a.lhs = b.ItemCode INNER JOIN
                         dbo.ItemDetails AS c ON a.rhs = c.ItemCode
GO

