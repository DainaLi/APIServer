CREATE VIEW [dbo].[KPIView]
AS
SELECT        dbo.[KPI Values].ParentCompany, dbo.[KPI Values].CompanyName, dbo.[KPI Values].YearCode, dbo.[KPI Values].MonthCode, dbo.[KPI Values].DayOfWeekNumber, dbo.[KPI Values].DayOfYear, 
                         dbo.[KPI Values].MonthCodeShort, dbo.[KPI Values].DayOfWeekName, dbo.[KPI Values].DayOfWeekNameShort, dbo.[KPI Values].DayOfMonth, dbo.[KPI Values].WeekEnd, dbo.[KPI Values].WeekDay, 
                         dbo.[KPI Values].WorkDay, dbo.[KPI Values].[Number Work Days In Month], dbo.[KPI Values].[Number NonWork Days In Month], dbo.[KPI Values].[Number Days In Month], dbo.[KPI Values].[Day Of Month], 
                         dbo.[KPI Values].WeekNumber, dbo.[KPI Values].[KPI Name], dbo.[KPI Values].[KPI Value Number], dbo.[KPI Values].[KPI Value String], dbo.[KPI Values].[KPI Value YesNo], dbo.[KPI Values].[Outlet Name], 
                         dbo.[KPI Values].LastUpdated, dbo.[KPI Values].[Unique Identity], dbo.[KPI Values].HourCode, dbo.[KPI Values].MinuteCode, dbo.[KPI Values].SecondCode, dbo.[KPI Values].AMPM, dbo.[KPI Values].PublicHoliday, 
                         dbo.[KPI Values].[Date Record], dbo.[KPI Values].CalculationDetails, dbo.[Outlet Details].Longitude03, dbo.[Outlet Details].Longitude02, dbo.[Outlet Details].Longitude01, dbo.[Outlet Details].Lattitude03, 
                         dbo.[Outlet Details].Lattitude02, dbo.[Outlet Details].Lattitude01, dbo.[Outlet Details].OutletCountry, dbo.[Outlet Details].OutletGroup05, dbo.[Outlet Details].OutletGroup04, dbo.[Outlet Details].OutletGroup03, 
                         dbo.[Outlet Details].OutletGroup02, dbo.[Outlet Details].OutletGroup01, dbo.[Outlet Details].Lattitude, dbo.[Outlet Details].Longitude, dbo.[Outlet Details].Tables, dbo.[Outlet Details].Seats, 
                         dbo.[Outlet Details].[Square Meter], dbo.[Outlet Details].[Square Foot], dbo.[Outlet Details].Description, dbo.[Outlet Details].[Description Long], dbo.[KPI Values].KPIGroup01 AS ItemName, 
                         dbo.[KPI Values].KPIGroup02 AS Channel, dbo.[KPI Values].KPIGroup03 AS [Meal Period], dbo.[KPI Values].KPIGroup04, dbo.[KPI Values].KPIGroup05, dbo.[KPI Values].KPIGroup06, dbo.[KPI Values].KPIGroup07, 
                         dbo.[KPI Values].KPIGroup08, dbo.[KPI Values].KPIGroup09, dbo.[KPI Values].KPIGroup10, dbo.[KPI Values].[Gross Margin], dbo.[KPI Values].[Cost Of Sales], dbo.[KPI Values].Expenses, 
                         dbo.[KPI Values].[Net Profit], dbo.[KPI Values].[Net Profit %], dbo.[KPI Values].[Gross Margin %], dbo.[KPI Values].Sales
FROM            dbo.[KPI Values] LEFT OUTER JOIN
                         dbo.[Outlet Details] ON dbo.[KPI Values].CompanyName = dbo.[Outlet Details].CompanyName AND dbo.[KPI Values].[Outlet Name] = dbo.[Outlet Details].[Outlet Name]
GO

