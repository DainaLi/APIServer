CREATE VIEW [dbo].[PredictionsView]
                    AS
                    SELECT        dbo.Predictions.[Outlet Name], dbo.Predictions.model_name, dbo.Predictions.predicted_date, dbo.Predictions.predicted_value_nvarchar, dbo.Predictions.predicted_value_decimal, dbo.Predictions.predicted_value_numeric, 
                         dbo.Predictions.predictions_name, dbo.Predictions.prediction_created_on, dbo.[Outlet Details].CompanyName, dbo.[Outlet Details].[Date Opened], dbo.[Outlet Details].[Date Closed], dbo.[Outlet Details].Tables, 
                         dbo.[Outlet Details].Seats, dbo.[Outlet Details].[Square Meter], dbo.[Outlet Details].[Square Foot], dbo.[Outlet Details].Description, dbo.[Outlet Details].[Description Long], dbo.[Outlet Details].Longitude, 
                         dbo.[Outlet Details].LastUpdated, dbo.[Outlet Details].Lattitude, dbo.[Outlet Details].OutletGroup01, dbo.[Outlet Details].OutletGroup02, dbo.[Outlet Details].OutletGroup03, dbo.[Outlet Details].OutletGroup04, 
                         dbo.[Outlet Details].OutletGroup05, dbo.[Outlet Details].OutletCountry, dbo.[Outlet Details].Lattitude01, dbo.[Outlet Details].Lattitude02, dbo.[Outlet Details].Lattitude03, dbo.[Outlet Details].Longitude01, 
                         dbo.[Outlet Details].Longitude02, dbo.[Outlet Details].Longitude03, dbo.[Outlet Details].[Outlet Code], dbo.[Outlet Details].[Prediction Model Name], dbo.[Outlet Details].PhysicalAddress01, dbo.[Outlet Details].PhysicalAddress02, 
                         dbo.[Outlet Details].Suburb, dbo.[Outlet Details].City, dbo.[Outlet Details].PostCode, dbo.[Outlet Details].State, dbo.[Outlet Details].Version, dbo.[Outlet Details].[Order number prefix], dbo.[Outlet Details].[Order number], 
                         dbo.[Outlet Details].[Supplier return prefix], dbo.[Outlet Details].[Supplier return number], dbo.[Outlet Details].[Low Stock Warning]
                    FROM            dbo.[Outlet Details] INNER JOIN
                         dbo.Predictions ON dbo.[Outlet Details].[Outlet Name] = dbo.Predictions.[Outlet Name]
GO

