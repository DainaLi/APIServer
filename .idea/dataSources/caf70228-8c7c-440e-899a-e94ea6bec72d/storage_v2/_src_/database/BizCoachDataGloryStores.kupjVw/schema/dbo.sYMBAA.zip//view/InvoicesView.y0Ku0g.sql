
CREATE VIEW [dbo].[InvoicesView]
AS
SELECT        dbo.Invoices.CompanyName, dbo.Invoices.ParentCompany, dbo.Invoices.InvoiceId, dbo.Invoices.Description, dbo.Invoices.ContactId, dbo.Invoices.ContactName, dbo.Invoices.ItemDescription, dbo.Invoices.ItemQuantity, 
                         dbo.Invoices.ItemAmount, dbo.Invoices.Units, dbo.Invoices.ItemCode, dbo.Invoices.AccountNumber, dbo.Invoices.TaxType, dbo.Invoices.TaxAmount, dbo.Invoices.LineAmount, dbo.Invoices.DateEntered, dbo.Invoices.DueDate, 
                         dbo.Invoices.CurrencyCode, dbo.Invoices.Rate, dbo.Invoices.InvoiceNumber, dbo.Invoices.Status, dbo.Invoices.SubTotal, dbo.Invoices.TotalTax, dbo.Invoices.Total, dbo.Invoices.TotalDiscount, dbo.Invoices.YearCode, 
                         dbo.Invoices.MonthCode, dbo.Invoices.DayOfWeekNumber, dbo.Invoices.DayOfYear, dbo.Invoices.MonthCodeShort, dbo.Invoices.DayOfWeekName, dbo.Invoices.DayOfWeekNameShort, dbo.Invoices.DayOfMonth, 
                         dbo.Invoices.LoadName, dbo.Invoices.UniqueID, dbo.Invoices.MonthCode01, dbo.Invoices.TaxCode01, dbo.Invoices.TaxCodeRate01, dbo.Invoices.TaxCodeAmount01, dbo.Invoices.TaxCode02, dbo.Invoices.TaxCodeAmount02, 
                         dbo.Invoices.TaxCodeRate02, dbo.Invoices.TaxCode03, dbo.Invoices.TaxCodeRate03, dbo.Invoices.TaxCodeAmount03, dbo.Invoices.TaxCode04, dbo.Invoices.TaxCodeRate04, dbo.Invoices.TaxCodeAmount04, 
                         dbo.Invoices.WeekEnd, dbo.Invoices.WeekDay, dbo.Invoices.WorkDay, dbo.Invoices.[Number Work Days In Month], dbo.Invoices.[Number Days In Month], dbo.Invoices.[Number NonWork Days In Month], 
                         dbo.Invoices.[Day Of Month], dbo.Invoices.WeekNumber, dbo.Invoices.HourCode, dbo.Invoices.MinuteCode, dbo.Invoices.SecondCode, dbo.Invoices.[Outlet Name], dbo.Invoices.Group01 AS MealPeriod, 
                         dbo.Invoices.Group02 AS Channel, dbo.Invoices.Group03 AS [Number Of Guests], dbo.Invoices.Group04 AS [Guests Per Invoice], dbo.Invoices.Group05 AS [Number Invoices], dbo.Invoices.Group06, dbo.Invoices.Group07, 
                         dbo.Invoices.Group09, dbo.Invoices.Group08, dbo.Invoices.AMPM, dbo.Invoices.LastUpdated, dbo.Invoices.Group10, dbo.Invoices.Group11, dbo.Invoices.Group12, dbo.ChartOfAccounts.AccountName, 
                         dbo.ChartOfAccounts.AccountType, dbo.ChartOfAccounts.Currency, dbo.ChartOfAccounts.SummaryAccount, dbo.ChartOfAccounts.UniqueIndex, dbo.ChartOfAccounts.Description AS [Account Description], 
                         dbo.ChartOfAccounts.LanguageCode, dbo.ChartOfAccounts.AccountBalance, dbo.ChartOfAccounts.[Sub Type], dbo.ChartOfAccounts.[Main Type], dbo.ChartOfAccounts.Segment, dbo.ChartOfAccounts.Division, 
                         dbo.ChartOfAccounts.Department, dbo.ChartOfAccounts.TaxType AS Expr2, dbo.ChartOfAccounts.SortType01, dbo.ChartOfAccounts.SortOrder01, dbo.ChartOfAccounts.SortType02, dbo.ChartOfAccounts.SortOrder02, 
                         dbo.ChartOfAccounts.SortType03, dbo.ChartOfAccounts.SortOrder03, dbo.ChartOfAccounts.SortType04, dbo.ChartOfAccounts.SortOrder04, dbo.ChartOfAccounts.Location, dbo.ChartOfAccounts.[Analytics Measure 01], 
                         dbo.ChartOfAccounts.[Analytics Measure 02], dbo.ChartOfAccounts.[Analytics Measure 03], dbo.ChartOfAccounts.[Analytics Measure 04], dbo.[Outlet Details].[Date Opened], dbo.[Outlet Details].[Date Closed], 
                         dbo.[Outlet Details].Tables, dbo.[Outlet Details].Seats, dbo.[Outlet Details].[Square Meter], dbo.[Outlet Details].[Square Foot], dbo.[Outlet Details].[Description Long], dbo.[Outlet Details].Lattitude, 
                         dbo.[Outlet Details].OutletGroup01 AS [Parent 1], dbo.[Outlet Details].OutletGroup03 AS [Parent 2], dbo.[Outlet Details].OutletGroup04, dbo.[Outlet Details].OutletGroup05, dbo.[Outlet Details].OutletGroup02, 
                         dbo.[Outlet Details].Longitude, dbo.[Outlet Details].Description AS [Outlet Description Short], dbo.[Outlet Details].OutletCountry, dbo.[Outlet Details].Lattitude01, dbo.[Outlet Details].Lattitude02, dbo.[Outlet Details].Lattitude03, 
                         dbo.[Outlet Details].Longitude01, dbo.[Outlet Details].Longitude02, dbo.[Outlet Details].Longitude03, dbo.Invoices.InvoicesGroup01, dbo.Invoices.InvoicesGroup02, dbo.Invoices.InvoicesGroup03, dbo.Invoices.InvoicesGroup04, 
                         dbo.Invoices.InvoicesGroup05, dbo.Invoices.InvoicesGroup06, dbo.Invoices.InvoicesGroup07, dbo.Invoices.InvoicesGroup08, dbo.Invoices.InvoicesGroup09, dbo.Invoices.InvoicesGroup10, dbo.Invoices.InvoicesGroup11, 
                         dbo.Invoices.InvoicesGroup12
FROM            dbo.Invoices LEFT OUTER JOIN
                         dbo.[Outlet Details] ON dbo.Invoices.[Outlet Name] = dbo.[Outlet Details].[Outlet Name] COLLATE Chinese_Hong_Kong_Stroke_90_BIN LEFT OUTER JOIN
                         dbo.ChartOfAccounts ON dbo.Invoices.AccountNumber = dbo.ChartOfAccounts.AccountNumber
GO

