
CREATE VIEW [dbo].[KPIInvoicesView]
AS
SELECT        ParentCompany, CompanyName, YearCode, MonthCode, DayOfWeekNumber, DayOfYear, MonthCodeShort, DayOfWeekName, DayOfWeekNameShort, DayOfMonth, WeekEnd, WeekDay, 
                         [Number Work Days In Month], WorkDay, [Number NonWork Days In Month], [Number Days In Month], [Day Of Month], WeekNumber, [KPI Name], [KPI Value Number], [KPI Value String], [KPI Value YesNo], 
                         [Outlet Name], LastUpdated, HourCode, MinuteCode, SecondCode, AMPM, PublicHoliday, [Date Record], CalculationDetails, KPIGroup01, KPIGroup02, KPIGroup03, KPIGroup04, KPIGroup05, KPIGroup06, 
                         KPIGroup07, KPIGroup08, KPIGroup09, KPIGroup10, [Detailed Description], [Gross Margin], [Cost Of Sales]
FROM            dbo.[KPI Values]
GO

