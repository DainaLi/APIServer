
CREATE VIEW [dbo].[SalesOrderLines ItemsDetails View]
AS
SELECT        dbo.SalesOrderLines.ParentCompany, dbo.SalesOrderLines.CompanyName, dbo.SalesOrderLines.IndexNumber, dbo.SalesOrderLines.[Date Record], dbo.SalesOrderLines.[Reference Number], 
                         dbo.SalesOrderLines.UniqueIdentity, dbo.SalesOrderLines.[SO Number], dbo.SalesOrderLines.[SO Date], dbo.SalesOrderLines.[Related Invoices], dbo.SalesOrderLines.[Shipped Date], dbo.SalesOrderLines.Status, 
                         dbo.SalesOrderLines.[Invoice Status], dbo.SalesOrderLines.Comments, dbo.SalesOrderLines.[Customer Name], dbo.SalesOrderLines.[Customer Code], dbo.SalesOrderLines.Quantity, dbo.SalesOrderLines.[Unit Of Measure], 
                         dbo.SalesOrderLines.[Cost Per UOM], dbo.SalesOrderLines.[Total Line Cost], dbo.SalesOrderLines.Description, dbo.SalesOrderLines.[Description Long], dbo.SalesOrderLines.[Required Date], dbo.SalesOrderLines.[Sales Rep], 
                         dbo.SalesOrderLines.COGS, dbo.SalesOrderLines.Profit, dbo.SalesOrderLines.Sale, dbo.SalesOrderLines.[Line Number], dbo.SalesOrderLines.[Outlet Name], dbo.SalesOrderLines.Group01, dbo.SalesOrderLines.Group02, 
                         dbo.SalesOrderLines.Group03, dbo.SalesOrderLines.Group04, dbo.SalesOrderLines.Group05, dbo.SalesOrderLines.Group06, dbo.SalesOrderLines.Group07, dbo.SalesOrderLines.AccountNumber, 
                         dbo.SalesOrderLines.AccountName, dbo.ItemDetails.Group01 AS ItemGroup01, dbo.ItemDetails.Group02 AS ItemGroup01ItemGroup02, dbo.ItemDetails.ItemCode, dbo.ItemDetails.Brand, dbo.ItemDetails.ItemName, 
                         dbo.ItemDetails.Description AS ItemDescription, dbo.ItemDetails.DescriptionLong, dbo.ItemDetails.ItemDetailsGroup01, dbo.ItemDetails.ItemDetailsGroup02, dbo.ItemDetails.Group03 AS Expr1, 
                         dbo.ItemDetails.ItemDetailsGroup03, dbo.ItemDetails.Group04 AS Expr2, dbo.ItemDetails.ItemDetailsGroup04, dbo.ItemDetails.Group05 AS Expr3, dbo.ItemDetails.ItemDetailsGroup05, dbo.ItemDetails.Group06 AS Expr4, 
                         dbo.ItemDetails.ItemDetailsGroup06, dbo.ItemDetails.Group07 AS Expr5, dbo.ItemDetails.ItemDetailsGroup07, dbo.ItemDetails.Group08, dbo.ItemDetails.ItemDetailsGroup08, dbo.ItemDetails.Group09, 
                         dbo.ItemDetails.ItemDetailsGroup09, dbo.ItemDetails.Group10, dbo.ItemDetails.ItemDetailsGroup10, dbo.ItemDetails.Group11, dbo.ItemDetails.ItemDetailsGroup11
FROM            dbo.SalesOrderLines LEFT OUTER JOIN
                         dbo.ItemDetails ON dbo.SalesOrderLines.ItemCode = dbo.ItemDetails.ItemCode
GO

