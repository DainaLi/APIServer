CREATE Trigger [dbo].[TRG_InsertCheckRegisters] ON [dbo].[Registers]
AFTER INSERT AS
DECLARE @unique_id uniqueidentifier, @latest_version bigint, @outlet_id uniqueidentifier, @sum_state bit;
DECLARE @states TABLE(is_open bit, registerid uniqueidentifier, outletid uniqueidentifier, deleteAt nvarchar(50));
DECLARE @states_rows int, @row_count int;
SET @unique_id = (select [Unique Identity] from inserted)
SET @latest_version = (select [Version] from inserted)
SET @outlet_id = (select [Outlet Id] from inserted); 

BEGIN
DELETE FROM Registers WHERE Registers.[Unique Identity] = @unique_id and Registers.[Version] < @latest_version;
INSERT INTO @states (is_open, registerid, outletid, deleteAt) 
SELECT [Is Open], [Unique Identity], [Outlet Id], [DeletedAt] from dbo.Registers where [Outlet Id]=@outlet_id and LEN(DeletedAt)=0;
SET @states_rows = (SELECT COUNT(*) FROM @states);
SET @row_count = 1;
SET @sum_state = 0; 
WHILE @row_count <= @states_rows
       BEGIN
           SET @sum_state = @sum_state | (select is_open from (select *, ROW_NUMBER() OVER (Order by registerid) As row_num from @states)A where A.row_num = @row_count);
              Print @sum_state;
              SET @row_count = @row_count+1;
       END;


IF @sum_state = 0
       BEGIN 
              INSERT INTO dbo.InventoryHistory ([UniqueIdentity], [ItemCode], [InventoryGroup01], [Quantity On Hand], [ReorderPoint]
              ,[InventoryGroup03], [Version], [TimeStamp], [TimePeriod])
              SELECT [UniqueIdentity], [ItemCode], [InventoryGroup01], [Quantity On Hand], 
              [ReorderPoint], [InventoryGroup03], [Version], GETUTCDATE(), 'End Of Day' FROM dbo.Inventory WHERE Inventory.InventoryGroup01 = @outlet_id
       END;
END;

GO

