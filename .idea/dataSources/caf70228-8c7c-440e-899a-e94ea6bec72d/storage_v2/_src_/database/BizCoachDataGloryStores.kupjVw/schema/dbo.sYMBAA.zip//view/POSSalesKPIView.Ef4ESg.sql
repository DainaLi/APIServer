
CREATE VIEW [dbo].[POSSalesKPIView]
AS
SELECT        dbo.POSSales.ParentCompany, dbo.POSSales.CompanyName, dbo.POSSales.IndexNumber, dbo.POSSales.[Date Record], dbo.POSSales.[Outlet Name], dbo.POSSales.[Reference Number], dbo.POSSales.Food, 
                         dbo.POSSales.Beverage, dbo.POSSales.Wine, dbo.POSSales.Others, dbo.POSSales.[ECP BV], dbo.POSSales.[Date Time], dbo.POSSales.[Total Net Sales], dbo.POSSales.CurrencyCode, dbo.POSSales.[Total Gross Sales], 
                         dbo.POSSales.Remarks, dbo.POSSales.Weather, dbo.POSSales.YearCode, dbo.POSSales.MonthCode, dbo.POSSales.DayOfWeekNumber, dbo.POSSales.DayOfYear, dbo.POSSales.MonthCodeShort, 
                         dbo.POSSales.DayOfWeekName, dbo.POSSales.DayOfWeekNameShort, dbo.POSSales.[Dinner Covers], dbo.POSSales.[Lunch Covers], dbo.POSSales.[Breakfast Covers], dbo.POSSales.[Lunch Cover Average], 
                         dbo.POSSales.[Average Check], dbo.POSSales.[Breakfast Cover Average], dbo.POSSales.[Payment Total], dbo.POSSales.[Discount Total], dbo.POSSales.[Five Percent Tax], dbo.POSSales.[Ten Percent Charge], 
                         dbo.POSSales.[Dinner Cover Average], dbo.POSSales.[Manager Dining Benefit], dbo.POSSales.EntbyEclipseCharge, dbo.POSSales.EntbyManagersCharge, dbo.POSSales.EntPromotionsCharge, dbo.POSSales.[Octopus Charge], 
                         dbo.POSSales.[Points Charge], dbo.POSSales.[China CC Charge], dbo.POSSales.[JCB Charge], dbo.POSSales.[Diner Charge], dbo.POSSales.[Master Charge], dbo.POSSales.[VISA Charge], dbo.POSSales.[Amex Charge], 
                         dbo.POSSales.[Cash Charge], dbo.POSSales.[Wastage Charge], dbo.POSSales.[Staff Drinks Charge], dbo.POSSales.[Manager Meals Charge], dbo.POSSales.[Food Tasting Charge], dbo.POSSales.[Discount 50 Total], 
                         dbo.POSSales.[Cigarette Charge], dbo.POSSales.[City Ledger Charge], dbo.POSSales.[Less Cr Card Tips Charge], dbo.POSSales.[Gross Sales], dbo.POSSales.[Rounding Total], dbo.POSSales.CashVoucherCoupon, 
                         dbo.POSSales.Barter, dbo.POSSales.Discount5, dbo.POSSales.Discount10, dbo.POSSales.Discount15, dbo.POSSales.Discount20, dbo.POSSales.Discount25, dbo.POSSales.Discount25_30, dbo.POSSales.Discount30, 
                         dbo.POSSales.Discount35, dbo.POSSales.Description, dbo.POSSales.DescriptionLong, dbo.POSSales.ItemName, dbo.POSSales.ItemCode, dbo.POSSales.CustomerName, dbo.POSSales.CustomerCode, 
                         dbo.POSSales.[Quantity Sold], dbo.POSSales.[Return], dbo.POSSales.Group01 AS Channel, dbo.POSSales.Group02 AS MealPeriod, dbo.POSSales.Group03, dbo.POSSales.Group04, dbo.POSSales.Group05, 
                         dbo.POSSales.Group06, dbo.POSSales.Group07, dbo.POSSales.DayOfMonth, dbo.POSSales.LoadName, dbo.POSSales.[Brunch Covers], dbo.POSSales.[Brunch Cover Average], dbo.POSSales.Foodora, 
                         dbo.POSSales.[Food By Web], dbo.POSSales.[Delivery Dot com], dbo.POSSales.[Food Panda], dbo.POSSales.DAD, dbo.POSSales.[Soho Delivery], dbo.POSSales.[Food By Fone], dbo.POSSales.Uber, dbo.POSSales.Cigarette, 
                         dbo.POSSales.Merchandise, dbo.POSSales.[Other Income], dbo.POSSales.[10% Service Charge], dbo.POSSales.Covers, dbo.POSSales.COGS, dbo.POSSales.Expenses, dbo.POSSales.WeekEnd, dbo.POSSales.WeekDay, 
                         dbo.POSSales.WorkDay, dbo.POSSales.[Number Work Days In Month], dbo.POSSales.[Number NonWork Days In Month], dbo.POSSales.[Number Days In Month], dbo.POSSales.[Day Of Month], dbo.POSSales.WeekNumber, 
                         dbo.POSSales.HourCode, dbo.POSSales.MinuteCode, dbo.POSSales.SecondCode, dbo.POSSales.AMPM, dbo.POSSales.LastUpdated, dbo.[Outlet Details].[Date Opened], dbo.[Outlet Details].[Date Closed], 
                         dbo.[Outlet Details].Tables, dbo.[Outlet Details].Seats, dbo.[Outlet Details].[Square Meter], dbo.[Outlet Details].[Square Foot], dbo.[Outlet Details].Description AS [Outlet Short Description], 
                         dbo.[Outlet Details].[Description Long] AS [Outlet Long Description], dbo.[Outlet Details].Longitude, dbo.[Outlet Details].Lattitude, dbo.ItemDetails.Brand, dbo.ItemDetails.Description AS ItemDescription, 
                         dbo.ItemDetails.DescriptionLong AS ItemDescriptionLong, dbo.ItemDetails.[Quantity On Hand], dbo.ItemDetails.[Return] AS ItemReturn, dbo.ItemDetails.[Quantity Reserved], dbo.ItemDetails.[Quantity on Hold], 
                         dbo.ItemDetails.[Value In Base], dbo.ItemDetails.[Standard Cost], dbo.ItemDetails.[Location Name], dbo.ItemDetails.LocationCode, dbo.ItemDetails.Class, dbo.ItemDetails.Type, dbo.ItemDetails.Group01 AS ItemGroup01, 
                         dbo.ItemDetails.Group02 AS ItemGroup02, dbo.ItemDetails.Group03 AS ItemGroup03, dbo.ItemDetails.Group04 AS ItemGroup04, dbo.ItemDetails.Group05 AS ItemGroup05, dbo.ItemDetails.Group06 AS ItemGroup06, 
                         dbo.ItemDetails.Group07 AS ItemGroup07, dbo.ItemDetails.Group08 AS ItemGroup08, dbo.ItemDetails.Group09 AS ItemGroup09, dbo.ItemDetails.Group10 AS ItemGroup10, dbo.ItemDetails.Group11 AS ItemGroup11, 
                         dbo.ItemDetails.TagPrice, dbo.ItemDetails.PromotionalPrice01, dbo.ItemDetails.PromotionalPrice02, dbo.ItemDetails.PromotionalPrice03, dbo.ItemDetails.LowestPrice, dbo.ItemDetails.Cost, 
                         dbo.ItemDetails.WeightedAverageCost, dbo.ItemDetails.LastReceiptDate, dbo.ItemDetails.LicenseCost, dbo.ItemDetails.SafetyLevel, dbo.ItemDetails.ReorderPoint, dbo.ItemDetails.SeasonalFactor, 
                         dbo.ItemDetails.[Unit Of Measure], dbo.ItemDetails.[Average Cost], dbo.ItemDetails.[Trade Price], dbo.ItemDetails.[Retail Price], dbo.ItemDetails.VendorCode, dbo.ItemDetails.VendorName, dbo.ItemDetails.[UOM Type], 
                         dbo.ItemDetails.[Cost Price], dbo.[Outlet Details].OutletGroup01 AS [Parent 1], dbo.[Outlet Details].OutletGroup02 AS [Parent 2], dbo.[Outlet Details].OutletGroup03, dbo.[Outlet Details].OutletGroup04, 
                         dbo.[Outlet Details].OutletGroup05, dbo.[Outlet Details].OutletCountry, dbo.ItemDetails.ItemType, dbo.ItemDetails.ItemGroup, dbo.ItemDetails.[Parent 1] AS [Item Parent 1], dbo.ItemDetails.[Parent 2] AS [Item Parent 2], 
                         dbo.[Outlet Details].Lattitude01, dbo.[Outlet Details].Lattitude02, dbo.[Outlet Details].Lattitude03, dbo.[Outlet Details].Longitude02, dbo.[Outlet Details].Longitude01, dbo.[Outlet Details].Longitude03, 
                         dbo.POSSales.POSSalesGroup01, dbo.POSSales.POSSalesGroup02, dbo.POSSales.POSSalesGroup03, dbo.POSSales.POSSalesGroup04, dbo.POSSales.POSSalesGroup05, dbo.POSSales.POSSalesGroup06, 
                         dbo.POSSales.POSSalesGroup07, dbo.ItemDetails.ItemDetailsGroup01, dbo.ItemDetails.ItemDetailsGroup02, dbo.ItemDetails.ItemDetailsGroup03, dbo.ItemDetails.ItemDetailsGroup04, dbo.ItemDetails.ItemDetailsGroup05, 
                         dbo.ItemDetails.ItemDetailsGroup06, dbo.ItemDetails.ItemDetailsGroup07, dbo.ItemDetails.ItemDetailsGroup08, dbo.ItemDetails.ItemDetailsGroup09, dbo.ItemDetails.ItemDetailsGroup10, 
                         dbo.ItemDetails.ItemDetailsGroup11
FROM            dbo.POSSales LEFT OUTER JOIN
                         dbo.ItemDetails ON dbo.POSSales.ItemName = dbo.ItemDetails.ItemCode LEFT OUTER JOIN
                         dbo.[Outlet Details] ON dbo.POSSales.[Outlet Name] = dbo.[Outlet Details].[Outlet Name]
GO

