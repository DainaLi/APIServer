CREATE VIEW [dbo].[JournalLinesView]
AS
SELECT        dbo.ChartOfAccounts.[Main Type], dbo.JournalLines.ParentCompany, dbo.JournalLines.CompanyName, dbo.JournalLines.[Voucher Date], dbo.JournalLines.[Voucher Number], dbo.JournalLines.CustVendorCode, 
                         dbo.JournalLines.AccountNumber, dbo.JournalLines.Description, dbo.JournalLines.Currency, dbo.JournalLines.[Exchange Rate], dbo.JournalLines.Column08, dbo.JournalLines.Column09, dbo.JournalLines.Column10, 
                         dbo.JournalLines.Amount, dbo.JournalLines.MonthCode01, dbo.JournalLines.[Account Name], dbo.JournalLines.Group01, dbo.JournalLines.Group02, dbo.JournalLines.Group03, dbo.JournalLines.Group04, 
                         dbo.JournalLines.Group05, dbo.JournalLines.Debitbase, dbo.JournalLines.CreditBase, dbo.JournalLines.IndexNumber, dbo.JournalLines.YearCode, dbo.JournalLines.MonthCode, dbo.JournalLines.DayOfWeekNumber, 
                         dbo.JournalLines.DayOfYear, dbo.JournalLines.MonthCodeShort, dbo.JournalLines.DayOfWeekName, dbo.JournalLines.DayOfWeekNameShort, dbo.JournalLines.AmountCurrency, dbo.JournalLines.DebitPosting, 
                         dbo.JournalLines.CreditPosting, dbo.JournalLines.Sales, dbo.JournalLines.UniqueID, dbo.JournalLines.Revenue, dbo.JournalLines.COGS, dbo.JournalLines.Expenses, dbo.JournalLines.DateTimeLoaded, 
                         dbo.JournalLines.Prototypetest, dbo.JournalLines.testLoad1, dbo.JournalLines.AmountBase, dbo.JournalLines.DayOfMonth, dbo.JournalLines.LoadName, dbo.ChartOfAccounts.[Sub Type], 
                         dbo.ChartOfAccounts.[Analytics Measure 04], dbo.ChartOfAccounts.[Analytics Measure 03], dbo.ChartOfAccounts.[Analytics Measure 02], dbo.ChartOfAccounts.[Analytics Measure 01], dbo.ChartOfAccounts.Location, 
                         dbo.ChartOfAccounts.SortOrder04, dbo.ChartOfAccounts.SortType04, dbo.ChartOfAccounts.SortOrder03, dbo.ChartOfAccounts.SortType03, dbo.ChartOfAccounts.SortOrder02, dbo.ChartOfAccounts.Segment, 
                         dbo.ChartOfAccounts.Division, dbo.ChartOfAccounts.Department, dbo.ChartOfAccounts.TaxType, dbo.ChartOfAccounts.SortType01, dbo.ChartOfAccounts.SortOrder01, dbo.ChartOfAccounts.SortType02, 
                         dbo.ChartOfAccounts.BizCoachDateCreated, dbo.JournalLines.COS, dbo.JournalLines.[Outlet Name], dbo.JournalLines.Equity, dbo.JournalLines.WeekEnd, dbo.JournalLines.WeekDay, dbo.JournalLines.WorkDay, 
                         dbo.JournalLines.[Number Work Days In Month], dbo.JournalLines.[Number NonWork Days In Month], dbo.JournalLines.[Number Days In Month], dbo.JournalLines.[Day Of Month], dbo.JournalLines.WeekNumber, 
                         dbo.JournalLines.Cash, dbo.JournalLines.[Vendor Code], dbo.JournalLines.[Customer Code], dbo.JournalLines.[Current Assets], dbo.JournalLines.[Long Term Assets], dbo.JournalLines.[Retained Earnings], 
                         dbo.JournalLines.[Current Liabilities], dbo.JournalLines.[Long Term Liabilities], dbo.JournalLines.LastUpdated, dbo.JournalLines.HourCode, dbo.JournalLines.MinuteCode, dbo.JournalLines.SecondCode, 
                         dbo.JournalLines.AMPM, dbo.[Outlet Details].[Date Opened], dbo.[Outlet Details].[Date Closed], dbo.[Outlet Details].Tables, dbo.[Outlet Details].Seats, dbo.[Outlet Details].[Square Foot], dbo.[Outlet Details].Description AS Expr1, 
                         dbo.[Outlet Details].[Description Long], dbo.[Outlet Details].Longitude, dbo.[Outlet Details].Lattitude, dbo.[Outlet Details].[Square Meter], dbo.[Outlet Details].OutletGroup01, dbo.[Outlet Details].OutletGroup02, 
                         dbo.[Outlet Details].OutletGroup03, dbo.[Outlet Details].OutletGroup04, dbo.[Outlet Details].OutletGroup05, dbo.JournalLines.MonthNumber, dbo.JournalLines.MonthNumber2Digits, dbo.JournalLines.JournalLinesGroup01, 
                         dbo.JournalLines.JournalLinesGroup02, dbo.JournalLines.JournalLinesGroup03, dbo.JournalLines.JournalLinesGroup04, dbo.JournalLines.JournalLinesGroup05, dbo.JournalLines.LastDateModified, 
                         dbo.ChartOfAccounts.AccountName, dbo.JournalLines.LastUpdate, dbo.[Outlet Details].Lattitude01, dbo.[Outlet Details].Lattitude02, dbo.[Outlet Details].Lattitude03, dbo.[Outlet Details].Longitude01, 
                         dbo.[Outlet Details].Longitude02, dbo.[Outlet Details].Longitude03, dbo.[Outlet Details].[Outlet Code], dbo.[Outlet Details].OutletCountry, dbo.[Outlet Details].LastUpdated AS Expr2
FROM            dbo.JournalLines INNER JOIN
                         dbo.ChartOfAccounts ON dbo.JournalLines.CompanyName = dbo.ChartOfAccounts.CompanyName AND dbo.JournalLines.AccountNumber = dbo.ChartOfAccounts.AccountNumber LEFT OUTER JOIN
                         dbo.[Outlet Details] ON dbo.JournalLines.[Outlet Name] = dbo.[Outlet Details].[Outlet Name]
GO

