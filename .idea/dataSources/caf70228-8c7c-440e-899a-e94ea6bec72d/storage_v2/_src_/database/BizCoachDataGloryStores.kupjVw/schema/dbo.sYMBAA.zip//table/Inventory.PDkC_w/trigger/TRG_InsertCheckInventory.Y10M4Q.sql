
Create Trigger TRG_InsertCheckInventory ON dbo.[Inventory]
AFTER INSERT AS
DECLARE @unique_id uniqueidentifier, @latest_version bigint;
SET @unique_id = (select [UniqueIdentity] from inserted)
SET @latest_version = (select [Version] from inserted)
BEGIN
DELETE FROM [Inventory] WHERE [Inventory].[UniqueIdentity] = @unique_id and [Inventory].[Version] < @latest_version
END;
GO

