
Create Trigger TRG_InsertCheckItemTaxesMapping ON dbo.ItemTaxesMapping
AFTER INSERT AS
DECLARE @outlet_id nvarchar(50), @item_code nvarchar(50), @version bigint;
SET @outlet_id = (select [Outlet Id] from inserted)
SET @item_code = (select [Item Code] from inserted)
SET @version = (select [Version] from inserted)
BEGIN
DELETE FROM ItemTaxesMapping WHERE ItemTaxesMapping.[Outlet Id] = @outlet_id and ItemTaxesMapping.[Version] < @version 
AND ItemTaxesMapping.[Item Code] = @item_code
END;
GO

