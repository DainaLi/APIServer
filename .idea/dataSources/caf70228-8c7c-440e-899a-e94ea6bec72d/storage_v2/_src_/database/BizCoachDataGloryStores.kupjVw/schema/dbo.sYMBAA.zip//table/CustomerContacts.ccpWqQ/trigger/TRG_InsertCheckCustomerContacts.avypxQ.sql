CREATE Trigger [dbo].[TRG_InsertCheckCustomerContacts] ON dbo.CustomerContacts
AFTER INSERT AS
DECLARE @unique_id uniqueidentifier, @latest_version bigint;
SET @unique_id = (select [Unique Identity] from inserted)
SET @latest_version = (select [Version] from inserted)
BEGIN
DELETE FROM [CustomerContacts] WHERE [CustomerContacts].[Unique Identity] = @unique_id and [CustomerContacts].[Version] < @latest_version
END;
GO

