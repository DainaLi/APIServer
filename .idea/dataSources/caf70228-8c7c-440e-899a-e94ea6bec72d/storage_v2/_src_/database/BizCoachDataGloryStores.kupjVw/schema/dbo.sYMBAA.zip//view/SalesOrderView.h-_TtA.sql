
CREATE VIEW [dbo].[SalesOrderView]
AS
SELECT        dbo.SalesOrderLines.[Date Record], dbo.SalesOrderLines.[SO Number], dbo.SalesOrderLines.[Line Number], dbo.SalesOrderLines.ItemName, dbo.SalesOrderLines.[Related Invoices], dbo.SalesOrderLines.[Shipped Date], 
                         dbo.SalesOrderLines.Status, dbo.SalesOrderLines.Comments, dbo.SalesOrderLines.Quantity, dbo.SalesOrderLines.[Unit Of Measure], dbo.SalesOrderLines.[Cost Per UOM], dbo.SalesOrderLines.[Total Line Cost], 
                         dbo.SalesOrderLines.Description, dbo.SalesOrderLines.[Description Long], dbo.SalesOrderLines.[Required Date], dbo.SalesOrderHeaders.CompanyName, dbo.SalesOrderHeaders.ParentCompany, 
                         dbo.SalesOrderHeaders.[Reference Number], dbo.SalesOrderLines.[Sales Rep], dbo.SalesOrderLines.COGS, dbo.SalesOrderLines.Profit, dbo.SalesOrderLines.Sale, dbo.SalesOrderLines.[Outlet Name], 
                         dbo.SalesOrderLines.SalesLineGroup01, dbo.SalesOrderLines.SalesLineGroup02, dbo.SalesOrderLines.SalesLineGroup03, dbo.SalesOrderLines.SalesLineGroup04, dbo.SalesOrderLines.SalesLineGroup05, 
                         dbo.SalesOrderLines.SalesLineGroup06, dbo.SalesOrderLines.SalesLineGroup07, dbo.SalesOrderLines.AccountNumber, dbo.SalesOrderLines.[Amount Tax], dbo.SalesOrderLines.ExternalSystemQualifier, 
                         dbo.SalesOrderLines.ExternalSystemID, dbo.SalesOrderLines.Currency, dbo.SalesOrderLines.Amount, dbo.SalesOrderLines.[Exchange Rate], dbo.SalesOrderLines.[Invoice Date], dbo.SalesOrderLines.AccountName, 
                         dbo.SalesOrderHeaders.HeaderRecord, dbo.SalesOrderHeaders.[Date Time], dbo.[Outlet Details].[Date Opened], dbo.[Outlet Details].[Date Closed], dbo.[Outlet Details].Tables, dbo.[Outlet Details].Seats, 
                         dbo.[Outlet Details].[Square Meter], dbo.[Outlet Details].[Square Foot], dbo.[Outlet Details].Description AS OutletDescription, dbo.[Outlet Details].[Description Long] AS OutletDescriptionLong, dbo.[Outlet Details].Longitude, 
                         dbo.[Outlet Details].Lattitude, dbo.[Outlet Details].OutletGroup01, dbo.[Outlet Details].OutletGroup02, dbo.[Outlet Details].OutletGroup03, dbo.[Outlet Details].OutletGroup04, dbo.[Outlet Details].Longitude03, 
                         dbo.[Outlet Details].Longitude02, dbo.[Outlet Details].Longitude01, dbo.[Outlet Details].Lattitude03, dbo.[Outlet Details].Lattitude02, dbo.[Outlet Details].Lattitude01, dbo.[Outlet Details].OutletCountry, 
                         dbo.[Outlet Details].OutletGroup05, dbo.SalesOrderHeaders.Amount AS [Header Amount], dbo.SalesOrderHeaders.Currency AS [Header Currency], dbo.SalesOrderLines.AMPM, dbo.SalesOrderLines.HourCode, 
                         dbo.SalesOrderLines.MinuteCode, dbo.SalesOrderLines.SecondCode, dbo.SalesOrderLines.WeekNumber, dbo.SalesOrderLines.[Day Of Month], dbo.SalesOrderLines.[Number Work Days In Month], 
                         dbo.SalesOrderLines.[Number NonWork Days In Month], dbo.SalesOrderLines.[Number Days In Month], dbo.SalesOrderLines.WeekEnd, dbo.SalesOrderLines.WeekDay, dbo.SalesOrderLines.WorkDay, 
                         dbo.SalesOrderLines.MonthNumber, dbo.SalesOrderLines.MonthNumber2Digits, dbo.SalesOrderLines.YearCode, dbo.SalesOrderLines.MonthCode, dbo.SalesOrderLines.DayOfYear, dbo.SalesOrderLines.DayOfWeekNumber, 
                         dbo.SalesOrderLines.MonthCodeShort, dbo.SalesOrderLines.DayOfWeekName, dbo.SalesOrderLines.DayOfWeekNameShort, dbo.SalesOrderLines.DayOfMonth, dbo.ItemDetails.Brand, dbo.ItemDetails.ItemCode, 
                         dbo.ItemDetails.LowestPrice, dbo.ItemDetails.Cost, dbo.ItemDetails.WeightedAverageCost, dbo.ItemDetails.LastReceiptDate, dbo.ItemDetails.[Retail Price], dbo.ItemDetails.[Trade Price], dbo.ItemDetails.[Cost Price], 
                         dbo.ItemDetails.[Average Cost], dbo.ItemDetails.ItemGroup, dbo.ItemDetails.ItemType, dbo.ItemDetails.Description AS Expr1, dbo.ItemDetails.DescriptionLong, dbo.[Outlet Details].[Outlet Code], 
                         dbo.SalesOrderLines.[Customer Name], dbo.SalesOrderLines.[Customer Code], dbo.SalesOrderLines.SalesCountryCode, dbo.SalesOrderLines.SalesCountry, dbo.SalesOrderLines.SalesCity, 
                         dbo.SalesOrderLines.SalesStateCounty, dbo.SalesOrderLines.SalesAddress, dbo.ItemDetails.Group01, dbo.ItemDetails.ItemDetailsGroup01, dbo.ItemDetails.Group02, dbo.ItemDetails.ItemDetailsGroup02, 
                         dbo.ItemDetails.Group03, dbo.ItemDetails.Group04, dbo.ItemDetails.ItemDetailsGroup04, dbo.ItemDetails.Group05, dbo.ItemDetails.ItemDetailsGroup05, dbo.ItemDetails.Group06, dbo.ItemDetails.ItemDetailsGroup06, 
                         dbo.ItemDetails.Group07, dbo.ItemDetails.ItemDetailsGroup03, dbo.ItemDetails.ItemDetailsGroup07, dbo.ItemDetails.Group08, dbo.ItemDetails.ItemDetailsGroup08, dbo.ItemDetails.Group09, 
                         dbo.ItemDetails.ItemDetailsGroup09, dbo.ItemDetails.Group10, dbo.ItemDetails.ItemDetailsGroup10, dbo.ItemDetails.Group11, dbo.ItemDetails.ItemDetailsGroup11, dbo.SalesOrderLines.IndexNumber, 
                         dbo.SalesOrderLines.[Invoice Status], dbo.SalesOrderLines.[SO Date]
FROM            dbo.ItemDetails RIGHT OUTER JOIN
                         dbo.SalesOrderLines ON dbo.ItemDetails.ItemName = dbo.SalesOrderLines.ItemName LEFT OUTER JOIN
                         dbo.SalesOrderHeaders ON dbo.SalesOrderLines.[SO Number] = dbo.SalesOrderHeaders.[SO Number] AND dbo.SalesOrderLines.[Line Number] = dbo.SalesOrderHeaders.[Line Number] LEFT OUTER JOIN
                         dbo.[Outlet Details] ON dbo.SalesOrderLines.[Outlet Name] = dbo.[Outlet Details].[Outlet Name]
GO

