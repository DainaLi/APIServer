
CREATE VIEW [dbo].[JournalView]
AS
SELECT        dbo.JournalLines.*, dbo.ChartOfAccounts.[Sub Type], dbo.ChartOfAccounts.[Main Type] AS Expr1, dbo.ChartOfAccounts.AccountName
FROM            dbo.ChartOfAccounts INNER JOIN
                         dbo.JournalLines ON dbo.ChartOfAccounts.CompanyName = dbo.JournalLines.CompanyName AND dbo.ChartOfAccounts.AccountNumber = dbo.JournalLines.AccountNumber
GO

