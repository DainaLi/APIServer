
CREATE VIEW [dbo].[POSSalesInvoicesView]
AS
SELECT        SUM(dbo.POSSales.[Total Net Sales]) AS [Net Sales], dbo.POSSales.Group02 AS [Meal Period], dbo.[Outlet Details].Seats, dbo.[Outlet Details].Tables, dbo.POSSales.[Date Record], dbo.[Outlet Details].[Square Meter], 
                         dbo.[Outlet Details].[Square Foot], dbo.[Outlet Details].Longitude, dbo.[Outlet Details].Lattitude, dbo.[Outlet Details].Description, dbo.Invoices.Group03 AS NumberGuests, dbo.Invoices.Group04 AS GuestsPerInvoice, 
                         dbo.Invoices.Group05 AS NumberInvoices, dbo.POSSales.[Outlet Name], dbo.[Outlet Details].OutletGroup01, dbo.[Outlet Details].OutletGroup02, dbo.[Outlet Details].OutletGroup03, dbo.[Outlet Details].OutletGroup04, 
                         dbo.[Outlet Details].OutletGroup05, dbo.[Outlet Details].OutletCountry, dbo.POSSales.YearCode, dbo.POSSales.MonthCode, dbo.POSSales.DayOfYear, dbo.Invoices.Group06, dbo.Invoices.Group07, 
                         dbo.Invoices.Group02 AS Channel, SUM(dbo.POSSales.COGS) AS COGS, SUM(dbo.POSSales.[Quantity Sold]) AS Units, dbo.[Outlet Details].Longitude03, dbo.[Outlet Details].Longitude02, dbo.[Outlet Details].Longitude01, 
                         dbo.[Outlet Details].Lattitude03, dbo.[Outlet Details].Lattitude01, dbo.[Outlet Details].Lattitude02, dbo.[Outlet Details].[Description Long], dbo.Invoices.Group01, dbo.Invoices.InvoicesGroup01, dbo.Invoices.InvoicesGroup02, 
                         dbo.Invoices.InvoicesGroup03, dbo.Invoices.InvoicesGroup04, dbo.Invoices.InvoicesGroup05, dbo.Invoices.InvoicesGroup06, dbo.Invoices.InvoicesGroup07, dbo.Invoices.Group08, dbo.Invoices.InvoicesGroup08, 
                         dbo.Invoices.Group09, dbo.Invoices.InvoicesGroup09, dbo.Invoices.Group10, dbo.Invoices.InvoicesGroup10, dbo.Invoices.Group11, dbo.Invoices.InvoicesGroup11, dbo.Invoices.Group12, dbo.Invoices.InvoicesGroup12, 
                         dbo.POSSales.Group01 AS Expr1, dbo.POSSales.POSSalesGroup01, dbo.POSSales.POSSalesGroup02, dbo.POSSales.Group03, dbo.POSSales.POSSalesGroup03, dbo.POSSales.Group04, dbo.POSSales.POSSalesGroup04, 
                         dbo.POSSales.Group05, dbo.POSSales.POSSalesGroup05, dbo.POSSales.Group06 AS Expr2, dbo.POSSales.POSSalesGroup06, dbo.POSSales.Group07 AS Expr3, dbo.POSSales.POSSalesGroup07
FROM            dbo.POSSales INNER JOIN
                         dbo.[Outlet Details] ON dbo.POSSales.[Outlet Name] = dbo.[Outlet Details].[Outlet Name] INNER JOIN
                         dbo.Invoices ON dbo.POSSales.Group02 = dbo.Invoices.Group01 AND dbo.POSSales.[Date Record] = dbo.Invoices.DateEntered AND dbo.POSSales.[Outlet Name] = dbo.Invoices.[Outlet Name]
GROUP BY dbo.POSSales.Group02, dbo.[Outlet Details].Seats, dbo.[Outlet Details].Tables, dbo.POSSales.[Date Record], dbo.[Outlet Details].[Square Meter], dbo.[Outlet Details].[Square Foot], dbo.[Outlet Details].Longitude, 
                         dbo.[Outlet Details].Lattitude, dbo.[Outlet Details].Description, dbo.Invoices.Group03, dbo.Invoices.Group04, dbo.Invoices.Group05, dbo.POSSales.[Outlet Name], dbo.[Outlet Details].OutletGroup01, 
                         dbo.[Outlet Details].OutletGroup02, dbo.[Outlet Details].OutletGroup03, dbo.[Outlet Details].OutletGroup04, dbo.[Outlet Details].OutletGroup05, dbo.[Outlet Details].OutletCountry, dbo.POSSales.YearCode, 
                         dbo.POSSales.MonthCode, dbo.POSSales.DayOfYear, dbo.Invoices.Group06, dbo.Invoices.Group07, dbo.Invoices.Group02, dbo.Invoices.Group01, dbo.[Outlet Details].Longitude03, dbo.[Outlet Details].Longitude02, 
                         dbo.[Outlet Details].Longitude01, dbo.[Outlet Details].Lattitude03, dbo.[Outlet Details].Lattitude01, dbo.[Outlet Details].Lattitude02, dbo.[Outlet Details].[Description Long], dbo.Invoices.InvoicesGroup01, 
                         dbo.Invoices.InvoicesGroup02, dbo.Invoices.InvoicesGroup03, dbo.Invoices.InvoicesGroup04, dbo.Invoices.InvoicesGroup05, dbo.Invoices.InvoicesGroup06, dbo.Invoices.InvoicesGroup07, dbo.Invoices.Group08, 
                         dbo.Invoices.InvoicesGroup08, dbo.Invoices.Group09, dbo.Invoices.InvoicesGroup09, dbo.Invoices.Group10, dbo.Invoices.InvoicesGroup10, dbo.Invoices.Group11, dbo.Invoices.InvoicesGroup11, dbo.Invoices.Group12, 
                         dbo.Invoices.InvoicesGroup12, dbo.POSSales.Group01, dbo.POSSales.POSSalesGroup01, dbo.POSSales.POSSalesGroup02, dbo.POSSales.Group03, dbo.POSSales.POSSalesGroup03, dbo.POSSales.Group04, 
                         dbo.POSSales.POSSalesGroup04, dbo.POSSales.Group05, dbo.POSSales.POSSalesGroup05, dbo.POSSales.Group06, dbo.POSSales.POSSalesGroup06, dbo.POSSales.Group07, dbo.POSSales.POSSalesGroup07
GO

