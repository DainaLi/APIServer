  CREATE Trigger [dbo].[TRG_InsertCheckPOSSales] ON [dbo].[POSSales]
AFTER INSERT AS
DECLARE @invoice_no nchar(30), @latest_version bigint;
SET @invoice_no = (select [Reference Number] from inserted)
SET @latest_version = (select [Version] from inserted)
BEGIN
INSERT INTO [POSSalesModifiedRecords] ([Unique Identity], [Outlet Code], [Outlet Name], [POSSalesGroup01],
  [Staff ID], [CustomerCode], [Reference Number], [POSSalesGroup02], [Description], [POSSalesGroup03],
  [DescriptionLong], [Total Gross Sales], [Total Net Sales], [Tax], [Group01], [Group02], [UpdatedAt],
  [Date Record], [Group03], [Line Number], [ItemCode], [POSSalesGroup04], [Discount Total], [Discount],
  [Line Total], [Price], [COGS], [Quantity Sold], [POSSalesGroup05], [Remarks], [POSSalesGroup06], [Group04],
  [Group05], [UnitCost], [Group06], [Number of Loyalty Pax], [Group07], [UnitTax], [POSSalesGroup07], 
  [POSSalesGroup08], [Revenue Generated Loyalty], [POSSalesGroup09], [POSSalesGroup10], [Return], [POSSalesGroup13],
  [POSSalesGroup14], [PaymentType01], [Payment Total], [POSSalesGroup15], [POSSalesGroup16], [Version], 
  [POSSalesGroup12],[Promotion Amount], [Promotion Name], [Promotion Id])
SELECT [Unique Identity], [Outlet Code], [Outlet Name], [POSSalesGroup01],
  [Staff ID], [CustomerCode], [Reference Number], [POSSalesGroup02], [Description], [POSSalesGroup03],
  [DescriptionLong], [Total Gross Sales], [Total Net Sales], [Tax], [Group01], [Group02], [UpdatedAt],
  [Date Record], [Group03], [Line Number], [ItemCode], [POSSalesGroup04], [Discount Total], [Discount],
  [Line Total], [Price], [COGS], [Quantity Sold], [POSSalesGroup05], [Remarks], [POSSalesGroup06], [Group04],
  [Group05], [UnitCost], [Group06], [Number of Loyalty Pax], [Group07], [UnitTax], [POSSalesGroup07], 
  [POSSalesGroup08], [Revenue Generated Loyalty], [POSSalesGroup09], [POSSalesGroup10], [Return], [POSSalesGroup13],
  [POSSalesGroup14], [PaymentType01], [Payment Total], [POSSalesGroup15], [POSSalesGroup16], [Version], 
  [POSSalesGroup12],[Promotion Amount], [Promotion Name], [Promotion Id] FROM POSSales WHERE POSSales.[Reference Number] = @invoice_no and POSSales.[Version] < @latest_version;

DELETE FROM POSSales WHERE POSSales.[Reference Number] = @invoice_no and POSSales.[Version] < @latest_version;
END;
  GO

