Create Trigger TRG_InsertCheckVendorHeaders ON dbo.VendorHeaders
AFTER INSERT AS
DECLARE @unique_id nvarchar(50), @latest_version bigint;
SET @unique_id = (select [Vendor Code] from inserted)
SET @latest_version = (select [Version] from inserted)
BEGIN
DELETE FROM [VendorHeaders] WHERE [VendorHeaders].[Vendor Code] = @unique_id and [VendorHeaders].[Version] < @latest_version
END;
GO

