Create Trigger TRG_InsertCheckItemDetails ON dbo.ItemDetails
AFTER INSERT AS
DECLARE @unique_id uniqueidentifier, @latest_version bigint;
SET @unique_id = (select [Unique Identity] from inserted)
SET @latest_version = (select [Version] from inserted)
BEGIN
DELETE FROM ItemDetails WHERE ItemDetails.[Unique Identity] = @unique_id and ItemDetails.[Version] < @latest_version
END;
GO

