
CREATE VIEW [dbo].[GlobalDailyView]
AS
SELECT        dbo.[Outlet Details].[Outlet Name], dbo.[Outlet Details].ParentCompany, dbo.[Outlet Details].CompanyName, dbo.[Outlet Details].[Date Opened], dbo.[Outlet Details].[Date Closed], dbo.[Outlet Details].Tables, 
                         dbo.[Outlet Details].Seats, dbo.[Outlet Details].[Square Meter], dbo.[Outlet Details].[Square Foot], dbo.[Outlet Details].Description, dbo.[Outlet Details].[Description Long], dbo.[Outlet Details].Longitude, 
                         dbo.[Outlet Details].Lattitude, dbo.[Outlet Details].OutletGroup01, dbo.[Outlet Details].OutletGroup02, dbo.[Outlet Details].OutletGroup03, dbo.[Outlet Details].OutletGroup04, dbo.[Outlet Details].OutletGroup05, 
                         dbo.ItemDetails.ItemCode, dbo.ItemDetails.Brand, dbo.ItemDetails.Description AS Expr1, dbo.ItemDetails.DescriptionLong, dbo.ItemDetails.CustomerName, dbo.ItemDetails.CustomerCode, dbo.ItemDetails.[Quantity On Hand], 
                         dbo.ItemDetails.[Return], dbo.ItemDetails.[Quantity Reserved], dbo.ItemDetails.[Quantity on Hold], dbo.ItemDetails.[Value In Base], dbo.ItemDetails.[Standard Cost], dbo.ItemDetails.[Location Name], 
                         dbo.ItemDetails.LocationCode, dbo.ItemDetails.Class, dbo.ItemDetails.Type, dbo.ItemDetails.Group01, dbo.ItemDetails.Group02, dbo.ItemDetails.Group03, dbo.ItemDetails.Group04, dbo.ItemDetails.Group06, 
                         dbo.ItemDetails.Group05, dbo.ItemDetails.Group07, dbo.ItemDetails.Group08, dbo.ItemDetails.Group09, dbo.ItemDetails.Group10, dbo.ItemDetails.Group11, dbo.ItemDetails.TagPrice, dbo.ItemDetails.PromotionalPrice01, 
                         dbo.ItemDetails.PromotionalPrice02, dbo.ItemDetails.LowestPrice, dbo.ItemDetails.PromotionalPrice03, dbo.ItemDetails.Cost, dbo.ItemDetails.WeightedAverageCost, dbo.ItemDetails.LastReceiptDate, 
                         dbo.ItemDetails.LicenseCost, dbo.ItemDetails.SafetyLevel, dbo.ItemDetails.ReorderPoint, dbo.ItemDetails.SeasonalFactor, dbo.ItemDetails.[Unit Of Measure], dbo.ItemDetails.[UOM Type], dbo.ItemDetails.VendorName, 
                         dbo.ItemDetails.VendorCode, dbo.ItemDetails.[Retail Price], dbo.ItemDetails.[Trade Price], dbo.ItemDetails.[Cost Price], dbo.ItemDetails.[Average Cost], dbo.OutletEmployeeLevels.AMPM, 
                         dbo.OutletEmployeeLevels.SecondCode, dbo.OutletEmployeeLevels.MinuteCode, dbo.OutletEmployeeLevels.HourCode, dbo.OutletEmployeeLevels.WeekNumber, dbo.OutletEmployeeLevels.[Day Of Month], 
                         dbo.OutletEmployeeLevels.[Number Days In Month], dbo.OutletEmployeeLevels.[Number NonWork Days In Month], dbo.OutletEmployeeLevels.WeekDay, dbo.OutletEmployeeLevels.WorkDay, 
                         dbo.OutletEmployeeLevels.[Number Work Days In Month], dbo.OutletEmployeeLevels.WeekEnd, dbo.OutletEmployeeLevels.DayOfMonth, dbo.OutletEmployeeLevels.DayOfWeekNameShort, 
                         dbo.OutletEmployeeLevels.DayOfWeekName, dbo.OutletEmployeeLevels.MonthCodeShort, dbo.OutletEmployeeLevels.DayOfYear, dbo.OutletEmployeeLevels.DayOfWeekNumber, dbo.OutletEmployeeLevels.MonthCode, 
                         dbo.OutletEmployeeLevels.YearCode, dbo.OutletEmployeeLevels.[Shift Name], dbo.OutletEmployeeLevels.[Number Employees], dbo.OutletEmployeeLevels.[Staff Type], dbo.OutletEmployeeLevels.[Date Record], 
                         dbo.Invoices.InvoiceId, dbo.Invoices.Description AS Expr2, dbo.Invoices.ContactId, dbo.Invoices.ContactName, dbo.Invoices.ItemDescription, dbo.Invoices.ItemQuantity, dbo.Invoices.ItemAmount, dbo.Invoices.Units, 
                         dbo.Invoices.ItemCode AS Expr3, dbo.Invoices.AccountNumber, dbo.Invoices.TaxType, dbo.Invoices.TaxAmount, dbo.Invoices.LineAmount, dbo.Invoices.DateEntered, dbo.Invoices.DueDate, dbo.Invoices.InvoiceNumber, 
                         dbo.Invoices.CurrencyCode, dbo.Invoices.Rate, dbo.Invoices.Status, dbo.Invoices.SubTotal, dbo.Invoices.TotalTax, dbo.Invoices.Total, dbo.Invoices.TotalDiscount, dbo.Invoices.LoadName, dbo.Invoices.UniqueID, 
                         dbo.Invoices.MonthCode01, dbo.Invoices.TaxCode01, dbo.Invoices.TaxCodeRate01, dbo.Invoices.TaxCodeAmount01, dbo.Invoices.TaxCode02, dbo.Invoices.TaxCodeRate02, dbo.Invoices.TaxCodeAmount02, 
                         dbo.Invoices.TaxCode03, dbo.Invoices.TaxCodeRate03, dbo.Invoices.TaxCodeAmount03, dbo.Invoices.TaxCode04, dbo.Invoices.TaxCodeRate04, dbo.Invoices.TaxCodeAmount04, dbo.Invoices.Group01 AS InvoiceGroup01, 
                         dbo.Invoices.Group02 AS InvoiceGroup012, dbo.Invoices.Group03 AS InvoiceGroup03, dbo.Invoices.Group04 AS InvoiceGroup014, dbo.Invoices.Group05 AS InvoiceGroup05, dbo.Invoices.Group06 AS InvoiceGroup06, 
                         dbo.Invoices.Group07 AS InvoiceGroup017, dbo.Invoices.Group08 AS InvoiceGroup08, dbo.Invoices.Group09 AS InvoiceGroup09, dbo.Invoices.Group10 AS InvoiceGroup10, dbo.Invoices.Group11 AS InvoiceGroup11, 
                         dbo.Invoices.Group12 AS InvoiceGroup12, dbo.JournalLines.[Voucher Number], dbo.JournalLines.AccountNumber AS JournalLinesAccountNumber, dbo.JournalLines.Description AS JournalLinesDescription, 
                         dbo.JournalLines.Currency, dbo.JournalLines.[Exchange Rate], dbo.JournalLines.Column08, dbo.JournalLines.Column09, dbo.JournalLines.Column10, dbo.JournalLines.[Main Type], dbo.JournalLines.Amount, 
                         dbo.JournalLines.SubType, dbo.JournalLines.MonthCode01 AS Expr38, dbo.JournalLines.[Account Name], dbo.JournalLines.Group01 AS JournalLinesGroup01, dbo.JournalLines.Group02 AS JournalLinesGroup02, 
                         dbo.JournalLines.Group04 AS JournalLinesGroup04, dbo.JournalLines.Group03 AS JournalLinesGroup03, dbo.JournalLines.Group05 AS JournalLinesGroup05, dbo.JournalLines.Debitbase, dbo.JournalLines.CreditBase, 
                         dbo.JournalLines.IndexNumber, dbo.JournalLines.MonthCode AS Expr45, dbo.JournalLines.Revenue, dbo.JournalLines.COGS, dbo.JournalLines.Expenses, dbo.JournalLines.AmountBase, dbo.JournalLines.[Vendor Code], 
                         dbo.JournalLines.[Customer Code], dbo.JournalLines.Cash, dbo.JournalLines.[Current Assets], dbo.JournalLines.[Long Term Assets], dbo.JournalLines.[Retained Earnings], dbo.JournalLines.[Current Liabilities], 
                         dbo.JournalLines.[Long Term Liabilities], dbo.JournalLines.Equity, dbo.JournalLines.COS, dbo.POSSales.[Reference Number], dbo.POSSales.Food, dbo.POSSales.Beverage, dbo.POSSales.Others, dbo.POSSales.Wine, 
                         dbo.POSSales.[ECP BV], dbo.POSSales.[ECP Wine], dbo.POSSales.[Total Net Sales], dbo.POSSales.CurrencyCode AS Expr46, dbo.POSSales.[Total Gross Sales], dbo.POSSales.Remarks, dbo.POSSales.Weather, 
                         dbo.POSSales.[Dinner Covers], dbo.POSSales.[Lunch Covers], dbo.POSSales.[Breakfast Covers], dbo.POSSales.[Lunch Cover Average], dbo.POSSales.[Average Check], dbo.POSSales.[Breakfast Cover Average], 
                         dbo.POSSales.[Payment Total], dbo.POSSales.[Discount Total], dbo.POSSales.[Five Percent Tax], dbo.POSSales.[Ten Percent Charge], dbo.POSSales.[Dinner Cover Average], dbo.POSSales.[Manager Dining Benefit], 
                         dbo.POSSales.EntbyEclipseCharge, dbo.POSSales.[Octopus Charge], dbo.POSSales.[Points Charge], dbo.POSSales.[China CC Charge], dbo.POSSales.[JCB Charge], dbo.POSSales.[Diner Charge], dbo.POSSales.[Master Charge], 
                         dbo.POSSales.[VISA Charge], dbo.POSSales.[Amex Charge], dbo.POSSales.[Cash Charge], dbo.POSSales.[Staff Drinks Charge], dbo.POSSales.[Wastage Charge], dbo.POSSales.[Manager Meals Charge], 
                         dbo.POSSales.[Food Tasting Charge], dbo.POSSales.[Discount 50 Total], dbo.POSSales.[Cigarette Charge], dbo.POSSales.[City Ledger Charge], dbo.POSSales.[Less Cr Card Tips Charge], dbo.POSSales.[Gross Sales], 
                         dbo.POSSales.[Rounding Total], dbo.POSSales.CashVoucherCoupon, dbo.POSSales.Barter, dbo.POSSales.Discount5, dbo.POSSales.Discount10, dbo.POSSales.Discount15, dbo.POSSales.Discount20, 
                         dbo.POSSales.Discount25, dbo.POSSales.Discount30, dbo.POSSales.Discount25_30, dbo.POSSales.Discount35, dbo.POSSales.Description AS Expr47, dbo.POSSales.DescriptionLong AS Expr48, dbo.ItemDetails.ItemName, 
                         dbo.POSSales.CustomerName AS POSSalesCustomerName, dbo.POSSales.CustomerCode AS POSSalesCustomerCode, dbo.POSSales.[Quantity Sold], dbo.POSSales.[Return] AS POSSalesReturn, 
                         dbo.POSSales.Group01 AS SalesGroup01, dbo.POSSales.Group02 AS SalesGroup02, dbo.POSSales.Group03 AS SalesGroup03, dbo.POSSales.Group04 AS SalesGroup04, dbo.POSSales.Group05 AS SalesGroup05, 
                         dbo.POSSales.Group06 AS SalesGroup06, dbo.POSSales.Group07 AS SalesGroup07, dbo.POSSales.[Brunch Covers], dbo.POSSales.[Brunch Cover Average], dbo.POSSales.[Food By Web], dbo.POSSales.Foodora, 
                         dbo.POSSales.[Delivery Dot com], dbo.POSSales.[Food Panda], dbo.POSSales.DAD, dbo.POSSales.[Soho Delivery], dbo.POSSales.[Food By Fone], dbo.POSSales.Uber, dbo.POSSales.Cigarette, dbo.POSSales.Merchandise, 
                         dbo.POSSales.[Other Income], dbo.POSSales.[10% Service Charge], dbo.POSSales.Covers, dbo.POSSales.COGS AS POSSalesCOGS, dbo.POSSales.Expenses AS POSSalesExpenses, dbo.[Outlet Details].Longitude03, 
                         dbo.[Outlet Details].Longitude02, dbo.[Outlet Details].Longitude01, dbo.[Outlet Details].Lattitude03, dbo.[Outlet Details].Lattitude02, dbo.[Outlet Details].Lattitude01, dbo.[Outlet Details].OutletCountry, 
                         dbo.Invoices.InvoicesGroup01, dbo.Invoices.InvoicesGroup02, dbo.Invoices.InvoicesGroup03, dbo.Invoices.InvoicesGroup04, dbo.Invoices.InvoicesGroup05, dbo.Invoices.InvoicesGroup06, dbo.Invoices.InvoicesGroup07, 
                         dbo.Invoices.InvoicesGroup08, dbo.Invoices.InvoicesGroup09, dbo.Invoices.InvoicesGroup10, dbo.Invoices.InvoicesGroup11, dbo.Invoices.InvoicesGroup12, dbo.POSSales.POSSalesGroup01, dbo.POSSales.POSSalesGroup02, 
                         dbo.POSSales.POSSalesGroup03, dbo.POSSales.POSSalesGroup04, dbo.POSSales.POSSalesGroup05, dbo.POSSales.POSSalesGroup06, dbo.POSSales.POSSalesGroup07, dbo.JournalLines.JournalLinesGroup01 AS Expr4, 
                         dbo.JournalLines.JournalLinesGroup02 AS Expr5, dbo.JournalLines.JournalLinesGroup03 AS Expr6, dbo.JournalLines.JournalLinesGroup04 AS Expr7, dbo.JournalLines.JournalLinesGroup05 AS Expr8, 
                         dbo.ItemDetails.ItemDetailsGroup01, dbo.ItemDetails.ItemDetailsGroup02, dbo.ItemDetails.ItemDetailsGroup03, dbo.ItemDetails.ItemDetailsGroup04, dbo.ItemDetails.ItemDetailsGroup05, dbo.ItemDetails.ItemDetailsGroup06, 
                         dbo.ItemDetails.ItemDetailsGroup07, dbo.ItemDetails.ItemDetailsGroup08, dbo.ItemDetails.ItemDetailsGroup09, dbo.ItemDetails.ItemDetailsGroup10, dbo.ItemDetails.ItemDetailsGroup11, 
                         dbo.OutletEmployeeLevels.[Employee Group01], dbo.OutletEmployeeLevels.[Employee Group02], dbo.OutletEmployeeLevels.[Employee Group03], dbo.OutletEmployeeLevels.[Employee Group04], 
                         dbo.OutletEmployeeLevels.[Employee Group05], dbo.OutletEmployeeLevels.[Employee Group06], dbo.OutletEmployeeLevels.[Employee Group07], dbo.OutletEmployeeLevels.[Employee Group08], 
                         dbo.OutletEmployeeLevels.[Employee Group09], dbo.OutletEmployeeLevels.[Employee Group10]
FROM            dbo.ItemDetails RIGHT OUTER JOIN
                         dbo.POSSales INNER JOIN
                         dbo.OutletEmployeeLevels INNER JOIN
                         dbo.JournalLines ON dbo.OutletEmployeeLevels.[Date Record] = dbo.JournalLines.[Voucher Date] ON dbo.POSSales.[Date Record] = dbo.JournalLines.[Voucher Date] INNER JOIN
                         dbo.Invoices ON dbo.JournalLines.[Voucher Date] = dbo.Invoices.DateEntered LEFT OUTER JOIN
                         dbo.[Outlet Details] ON dbo.OutletEmployeeLevels.[Outlet Name] = dbo.[Outlet Details].[Outlet Name] ON dbo.ItemDetails.ItemName = dbo.POSSales.ItemName
GO

