     CREATE Trigger [dbo].[TRG_InsertCheckConsignment] ON [dbo].[PurchaseOrderLines]
AFTER INSERT AS
DECLARE @unique_id uniqueidentifier, @latest_version bigint;
SET @unique_id = (select [UniqueIdentity] from inserted)
SET @latest_version = (select [Version] from inserted)
BEGIN
INSERT INTO [PurchaseOrderModifiedLines] ([UniqueIdentity], [PO Number], [Outlet Id], [PO Name],
[Required Date], [Type], [Status], [Vendor Code], [Source Outlet Id], [PO Date], [Received At], 
[Related Invoices], [Reference Number], [POGroup01], [POGroup02], [POGroup03], [POGroup04],
[Date Time], [Updated At], [Deleted At], [Version])
SELECT [UniqueIdentity], [PO Number], [Outlet Id], [PO Name],
[Required Date], [Type], [Status], [Vendor Code], [Source Outlet Id], [PO Date], [Received At], 
[Related Invoices], [Reference Number], [POGroup01], [POGroup02], [POGroup03], [POGroup04],
[Date Time], [Updated At], [Deleted At], [Version] FROM [PurchaseOrderLines] WHERE [PurchaseOrderLines].[UniqueIdentity] = @unique_id and [PurchaseOrderLines].[Version] < @latest_version;
DELETE FROM [PurchaseOrderLines] WHERE [PurchaseOrderLines].[UniqueIdentity] = @unique_id and [PurchaseOrderLines].[Version] < @latest_version;
END;
     GO

