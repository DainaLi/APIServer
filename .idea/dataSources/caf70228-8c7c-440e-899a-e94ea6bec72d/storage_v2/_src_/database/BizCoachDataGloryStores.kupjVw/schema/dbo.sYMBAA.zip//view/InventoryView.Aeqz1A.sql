CREATE VIEW dbo.InventoryView
AS
SELECT        dbo.Inventory.ItemCode, dbo.Inventory.CustomerName, dbo.Inventory.CustomerCode, dbo.Inventory.[Quantity On Hand], dbo.Inventory.[Return], dbo.Inventory.[Quantity Reserved], dbo.Inventory.[Quantity on Hold], 
                         dbo.Inventory.[Value In Base], dbo.Inventory.[Location Name], dbo.Inventory.LocationCode, dbo.Inventory.Group01, dbo.Inventory.InventoryGroup01, dbo.Inventory.Group02, dbo.Inventory.InventoryGroup02, 
                         dbo.Inventory.Group03, dbo.Inventory.InventoryGroup03, dbo.Inventory.Group04, dbo.Inventory.InventoryGroup04, dbo.Inventory.Group05, dbo.Inventory.InventoryGroup05, dbo.Inventory.Group06, 
                         dbo.Inventory.InventoryGroup06, dbo.Inventory.Group07, dbo.Inventory.InventoryGroup07, dbo.Inventory.Group08, dbo.Inventory.InventoryGroup08, dbo.Inventory.Group09, dbo.Inventory.InventoryGroup09, 
                         dbo.Inventory.Group10, dbo.Inventory.InventoryGroup10, dbo.Inventory.Group11, dbo.Inventory.InventoryGroup11, dbo.Inventory.TagPrice, dbo.Inventory.PromotionalPrice01, dbo.Inventory.PromotionalPrice02, 
                         dbo.Inventory.PromotionalPrice03, dbo.Inventory.LowestPrice, dbo.Inventory.Cost, dbo.Inventory.WeightedAverageCost, dbo.Inventory.LastReceiptDate, dbo.Inventory.LicenseCost, dbo.Inventory.SafetyLevel, 
                         dbo.Inventory.ReorderPoint, dbo.Inventory.SeasonalFactor, dbo.Inventory.[Unit Of Measure], dbo.Inventory.[UOM Type], dbo.Inventory.ExternalSystemID, dbo.Inventory.ExternalSystemQualifier, 
                         dbo.Inventory.[Warehouse Name], dbo.Inventory.[Date Entered], dbo.Inventory.UniqueIndex, dbo.Inventory.LastUpdated, dbo.Inventory.LastModified, dbo.Inventory.Consignment, dbo.Inventory.UniqueIdentity, 
                         dbo.Inventory.Version, dbo.ItemDetails.Brand, dbo.ItemDetails.ItemName, dbo.ItemDetails.VariantName, dbo.ItemDetails.Description, dbo.ItemDetails.DescriptionLong, dbo.ItemDetails.[Standard Cost], 
                         dbo.ItemDetails.[Location Name] AS Expr13, dbo.ItemDetails.LocationCode AS Expr14, dbo.ItemDetails.Class, dbo.ItemDetails.Type, dbo.ItemDetails.Group01 AS Expr15, dbo.ItemDetails.ItemDetailsGroup01, 
                         dbo.ItemDetails.ItemDetailsGroup02, dbo.ItemDetails.ItemDetailsGroup03, dbo.ItemDetails.ItemDetailsGroup04, dbo.ItemDetails.ItemDetailsGroup05, dbo.ItemDetails.ItemDetailsGroup06, dbo.ItemDetails.ItemDetailsGroup07, 
                         dbo.ItemDetails.ItemDetailsGroup08, dbo.ItemDetails.ItemDetailsGroup09, dbo.ItemDetails.ItemDetailsGroup10, dbo.ItemDetails.ItemDetailsGroup11, dbo.ItemDetails.Cost AS ItemCost, dbo.ItemDetails.[Cost Price], 
                         dbo.ItemDetails.[Item Group]
FROM            dbo.Inventory INNER JOIN
                         dbo.ItemDetails ON dbo.Inventory.ItemCode = dbo.ItemDetails.ItemCode
GO

