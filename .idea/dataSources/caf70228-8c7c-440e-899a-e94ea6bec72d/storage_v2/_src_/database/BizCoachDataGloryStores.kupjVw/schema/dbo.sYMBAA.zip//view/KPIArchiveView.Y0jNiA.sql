

CREATE VIEW [dbo].[KPIArchiveView]
AS
SELECT        dbo.[KPI Values Archive].ParentCompany, dbo.[KPI Values Archive].CompanyName, dbo.[KPI Values Archive].YearCode, dbo.[KPI Values Archive].MonthCode, dbo.[KPI Values Archive].DayOfWeekNumber, 
                         dbo.[KPI Values Archive].DayOfYear, dbo.[KPI Values Archive].MonthCodeShort, dbo.[KPI Values Archive].DayOfWeekName, dbo.[KPI Values Archive].DayOfWeekNameShort, dbo.[KPI Values Archive].DayOfMonth, 
                         dbo.[KPI Values Archive].WeekEnd, dbo.[KPI Values Archive].WeekDay, dbo.[KPI Values Archive].WorkDay, dbo.[KPI Values Archive].[Number Work Days In Month], 
                         dbo.[KPI Values Archive].[Number NonWork Days In Month], dbo.[KPI Values Archive].[Number Days In Month], dbo.[KPI Values Archive].[Day Of Month], dbo.[KPI Values Archive].WeekNumber, 
                         dbo.[KPI Values Archive].[KPI Name], dbo.[KPI Values Archive].[KPI Value Number], dbo.[KPI Values Archive].[KPI Value String], dbo.[KPI Values Archive].[KPI Value YesNo], dbo.[KPI Values Archive].[Outlet Name], 
                         dbo.[KPI Values Archive].LastUpdated, dbo.[KPI Values Archive].[Unique Identity], dbo.[KPI Values Archive].HourCode, dbo.[KPI Values Archive].MinuteCode, dbo.[KPI Values Archive].SecondCode, 
                         dbo.[KPI Values Archive].AMPM, dbo.[KPI Values Archive].PublicHoliday, dbo.[KPI Values Archive].[Date Record], dbo.[KPI Values Archive].CalculationDetails, dbo.[KPI Values Archive].KPIGroup01, 
                         dbo.[KPI Values Archive].KPIGroup02, dbo.[KPI Values Archive].KPIGroup03, dbo.[KPI Values Archive].KPIGroup04, dbo.[KPI Values Archive].KPIGroup05, dbo.[KPI Values Archive].KPIGroup06, 
                         dbo.[KPI Values Archive].KPIGroup07, dbo.[KPI Values Archive].KPIGroup08, dbo.[KPI Values Archive].KPIGroup09, dbo.[KPI Values Archive].KPIGroup10, dbo.[KPI Values Archive].[Detailed Description], 
                         dbo.[KPI Values Archive].[Gross Margin], dbo.[KPI Values Archive].[Cost Of Sales], dbo.[KPI Values Archive].Expenses, dbo.[KPI Values Archive].[Net Profit], dbo.[KPI Values Archive].[Net Profit %], 
                         dbo.[KPI Values Archive].[Gross Margin %], dbo.[KPI Values Archive].Sales, dbo.[KPI Values Archive].[Date Of KPI], dbo.[Outlet Details].[Date Opened], dbo.[Outlet Details].[Date Closed], dbo.[Outlet Details].Tables, 
                         dbo.[Outlet Details].Seats, dbo.[Outlet Details].[Square Meter], dbo.[Outlet Details].[Square Foot], dbo.[Outlet Details].Description, dbo.[Outlet Details].[Description Long], dbo.[Outlet Details].Longitude, 
                         dbo.[Outlet Details].Lattitude, dbo.[Outlet Details].LastUpdated AS Expr1, dbo.[Outlet Details].OutletGroup01, dbo.[Outlet Details].OutletGroup02, dbo.[Outlet Details].OutletGroup03, 
                         dbo.[Outlet Details].OutletGroup05, dbo.[Outlet Details].OutletGroup04, dbo.[Outlet Details].OutletCountry, dbo.[Outlet Details].Lattitude01, dbo.[Outlet Details].Lattitude02, dbo.[Outlet Details].Lattitude03, 
                         dbo.[Outlet Details].Longitude01, dbo.[Outlet Details].Longitude02, dbo.[Outlet Details].Longitude03, dbo.[Outlet Details].[Outlet Code], dbo.[Outlet Details].[Prediction Model Name]
FROM            dbo.[KPI Values Archive] LEFT OUTER JOIN
                         dbo.[Outlet Details] ON dbo.[KPI Values Archive].CompanyName = dbo.[Outlet Details].CompanyName AND dbo.[KPI Values Archive].[Outlet Name] = dbo.[Outlet Details].[Outlet Name]
GO

