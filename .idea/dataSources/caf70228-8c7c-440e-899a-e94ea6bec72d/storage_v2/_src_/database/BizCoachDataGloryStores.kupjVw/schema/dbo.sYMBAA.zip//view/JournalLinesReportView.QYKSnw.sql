
CREATE VIEW [dbo].[JournalLinesReportView]
AS
SELECT        dbo.JournalLines.ParentCompany, dbo.JournalLines.CompanyName, SUM(dbo.JournalLines.Amount) AS Amount, dbo.JournalLines.MonthCode01, dbo.ChartOfAccounts.[Main Type], dbo.ChartOfAccounts.[Sub Type], 
                         SUM(dbo.JournalLines.Sales) AS Sales, SUM(dbo.JournalLines.COGS) AS COGS, SUM(dbo.JournalLines.Expenses) AS Expenses, dbo.ChartOfAccounts.SortType01, dbo.ChartOfAccounts.SortOrder01, 
                         dbo.ChartOfAccounts.SortType02, dbo.ChartOfAccounts.Division, dbo.ChartOfAccounts.Department, dbo.ChartOfAccounts.Segment, dbo.ChartOfAccounts.[Analytics Measure 01], dbo.ChartOfAccounts.[Analytics Measure 02], 
                         dbo.ChartOfAccounts.[Analytics Measure 03], dbo.ChartOfAccounts.[Analytics Measure 04], dbo.ChartOfAccounts.Description, dbo.ChartOfAccounts.SortOrder02, dbo.ChartOfAccounts.SortType03, dbo.ChartOfAccounts.SortOrder03,
                          dbo.ChartOfAccounts.SortType04, dbo.ChartOfAccounts.SortOrder04, dbo.ChartOfAccounts.BizCoachDateCreated, dbo.ChartOfAccounts.Location, dbo.JournalLines.Group01, dbo.JournalLines.JournalLinesGroup01, 
                         dbo.JournalLines.Group02, dbo.JournalLines.JournalLinesGroup02, dbo.JournalLines.Group03, dbo.JournalLines.JournalLinesGroup03, dbo.JournalLines.Group04, dbo.JournalLines.JournalLinesGroup04, 
                         dbo.JournalLines.Group05, dbo.JournalLines.JournalLinesGroup05
FROM            dbo.JournalLines LEFT OUTER JOIN
                         dbo.ChartOfAccounts ON dbo.JournalLines.AccountNumber = dbo.ChartOfAccounts.AccountNumber AND dbo.JournalLines.CompanyName = dbo.ChartOfAccounts.CompanyName
GROUP BY dbo.JournalLines.CompanyName, dbo.JournalLines.ParentCompany, dbo.JournalLines.MonthCode01, dbo.ChartOfAccounts.[Main Type], dbo.ChartOfAccounts.[Sub Type], dbo.ChartOfAccounts.SortType01, 
                         dbo.ChartOfAccounts.SortOrder01, dbo.ChartOfAccounts.SortType02, dbo.ChartOfAccounts.Division, dbo.ChartOfAccounts.Department, dbo.ChartOfAccounts.Segment, dbo.ChartOfAccounts.[Analytics Measure 01], 
                         dbo.ChartOfAccounts.[Analytics Measure 02], dbo.ChartOfAccounts.[Analytics Measure 03], dbo.ChartOfAccounts.[Analytics Measure 04], dbo.ChartOfAccounts.Description, dbo.ChartOfAccounts.SortOrder02, 
                         dbo.ChartOfAccounts.SortType03, dbo.ChartOfAccounts.SortOrder03, dbo.ChartOfAccounts.SortType04, dbo.ChartOfAccounts.SortOrder04, dbo.ChartOfAccounts.BizCoachDateCreated, dbo.ChartOfAccounts.Location, 
                         dbo.JournalLines.Group01, dbo.JournalLines.JournalLinesGroup01, dbo.JournalLines.Group02, dbo.JournalLines.JournalLinesGroup02, dbo.JournalLines.Group03, dbo.JournalLines.JournalLinesGroup03, 
                         dbo.JournalLines.Group04, dbo.JournalLines.JournalLinesGroup04, dbo.JournalLines.Group05, dbo.JournalLines.JournalLinesGroup05
GO

