
CREATE VIEW [dbo].[Sales By Product View]
AS
SELECT        TOP (100) PERCENT ItemName, SUM(Quantity) AS Quantity, SUM([Total Line Cost]) AS [Total Sale]
FROM            dbo.SalesOrderLines
GROUP BY ItemName
GO

