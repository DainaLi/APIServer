
CREATE VIEW [dbo].[EmployeesView]
AS
SELECT        dbo.OutletEmployeeLevels.ParentCompany, dbo.OutletEmployeeLevels.CompanyName, dbo.OutletEmployeeLevels.[Outlet Name], dbo.OutletEmployeeLevels.[Staff Type], 
                         dbo.OutletEmployeeLevels.[Date Record], dbo.OutletEmployeeLevels.[Number Employees], dbo.OutletEmployeeLevels.[Shift Name], dbo.OutletEmployeeLevels.YearCode, dbo.OutletEmployeeLevels.MonthCode, 
                         dbo.OutletEmployeeLevels.DayOfWeekNumber, dbo.OutletEmployeeLevels.DayOfYear, dbo.OutletEmployeeLevels.MonthCodeShort, dbo.OutletEmployeeLevels.DayOfWeekName, 
                         dbo.OutletEmployeeLevels.DayOfWeekNameShort, dbo.OutletEmployeeLevels.DayOfMonth, dbo.OutletEmployeeLevels.WeekEnd, dbo.OutletEmployeeLevels.WeekDay, dbo.OutletEmployeeLevels.WorkDay, 
                         dbo.OutletEmployeeLevels.[Number Work Days In Month], dbo.OutletEmployeeLevels.[Number NonWork Days In Month], dbo.OutletEmployeeLevels.[Number Days In Month], 
                         dbo.OutletEmployeeLevels.WeekNumber, dbo.OutletEmployeeLevels.[Day Of Month], dbo.OutletEmployeeLevels.MinuteCode, dbo.OutletEmployeeLevels.HourCode, dbo.OutletEmployeeLevels.SecondCode, 
                         dbo.OutletEmployeeLevels.AMPM, dbo.[Outlet Details].[Date Opened], dbo.[Outlet Details].[Date Closed], dbo.[Outlet Details].Tables, dbo.[Outlet Details].Seats, dbo.[Outlet Details].[Square Meter], 
                         dbo.[Outlet Details].[Square Foot], dbo.[Outlet Details].Description, dbo.[Outlet Details].[Description Long], dbo.[Outlet Details].Lattitude, dbo.[Outlet Details].OutletGroup01, dbo.[Outlet Details].Longitude, 
                         dbo.[Outlet Details].OutletGroup02, dbo.[Outlet Details].OutletGroup03, dbo.[Outlet Details].OutletGroup04, dbo.[Outlet Details].OutletGroup05, dbo.[Outlet Details].OutletCountry, dbo.[Outlet Details].Lattitude01, 
                         dbo.[Outlet Details].Lattitude02, dbo.[Outlet Details].Lattitude03, dbo.[Outlet Details].Longitude01, dbo.[Outlet Details].Longitude02, dbo.[Outlet Details].Longitude03, dbo.OutletEmployeeLevels.[Employee Cost], 
                         dbo.OutletEmployeeLevels.[Employee Group01], dbo.OutletEmployeeLevels.[Employee Group02], dbo.OutletEmployeeLevels.[Employee Group03], dbo.OutletEmployeeLevels.[Employee Group04], 
                         dbo.OutletEmployeeLevels.[Employee Group05], dbo.OutletEmployeeLevels.[Employee Group06], dbo.OutletEmployeeLevels.[Employee Group07], dbo.OutletEmployeeLevels.[Employee Group08], 
                         dbo.OutletEmployeeLevels.[Employee Group10], dbo.OutletEmployeeLevels.[Employee Group09], Dimensions_1.[Parent 1], Dimensions_1.[Description Long] AS Expr1, Dimensions_1.[Description Short], 
                         dbo.Dimensions.[Parent 1] AS Expr2, dbo.Dimensions.[Description Long] AS Expr3, dbo.Dimensions.[Description Short] AS Expr4, dbo.Dimensions.[Parent 2], Dimensions_2.[Description Short] AS Expr5, 
                         Dimensions_2.[Parent 1] AS Expr6, Dimensions_2.[Parent 2] AS Expr7, Dimensions_2.[Description Long] AS [Outlet Group Name]
FROM            dbo.Dimensions AS Dimensions_2 INNER JOIN
                         dbo.[Outlet Details] ON Dimensions_2.[Dimension Value] = dbo.[Outlet Details].OutletGroup03 LEFT OUTER JOIN
                         dbo.Dimensions ON dbo.[Outlet Details].OutletCountry = dbo.Dimensions.[Dimension Value] RIGHT OUTER JOIN
                         dbo.OutletEmployeeLevels LEFT OUTER JOIN
                         dbo.Dimensions AS Dimensions_1 ON dbo.OutletEmployeeLevels.[Shift Name] = Dimensions_1.[Dimension Value] ON dbo.[Outlet Details].[Outlet Name] = dbo.OutletEmployeeLevels.[Outlet Name]
GO

