Create Trigger TRG_InsertCheckOutletDetails ON dbo.[Outlet Details] 
                AFTER INSERT AS 
DECLARE @unique_id uniqueidentifier, @latest_version bigint; 
SET @unique_id = (select [Unique Identity] from inserted) 
SET @latest_version = (select [Version] from inserted) 
BEGIN 
DELETE FROM [Outlet Details] WHERE [Outlet Details].[Unique Identity] = @unique_id and [Outlet Details].[Version] < @latest_version 
END;
GO

