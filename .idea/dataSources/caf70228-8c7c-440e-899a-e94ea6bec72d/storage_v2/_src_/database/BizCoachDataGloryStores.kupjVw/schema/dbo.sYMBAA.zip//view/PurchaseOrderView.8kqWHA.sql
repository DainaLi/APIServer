
CREATE VIEW [dbo].[PurchaseOrderView]
AS
SELECT        dbo.PurchaseOrderLines.[PO Number], dbo.PurchaseOrderLines.[Line Number], dbo.PurchaseOrderLines.[Date Record], dbo.PurchaseOrderHeaders.[Reference Number], dbo.PurchaseOrderHeaders.Amount, 
                         dbo.PurchaseOrderHeaders.[Exchange Rate], dbo.PurchaseOrderHeaders.[Amount Tax], dbo.PurchaseOrderHeaders.PurchaseCountryCode, dbo.PurchaseOrderHeaders.PurchaseCountry, 
                         dbo.PurchaseOrderHeaders.PurchaseCity, dbo.PurchaseOrderHeaders.PurchaseAddress, dbo.PurchaseOrderHeaders.PurchaseStateCounty, dbo.PurchaseOrderLines.ItemName, dbo.PurchaseOrderLines.Status, 
                         dbo.PurchaseOrderLines.ItemCode, dbo.PurchaseOrderLines.Quantity, dbo.PurchaseOrderLines.[Unit Of Measure], dbo.PurchaseOrderLines.[Cost Per UOM], dbo.PurchaseOrderLines.[Total Line Cost], 
                         dbo.PurchaseOrderLines.Currency AS [Line Currency], dbo.PurchaseOrderLines.Amount AS [Line Amount], dbo.PurchaseOrderLines.[Exchange Rate] AS [Line Exchange Rate], dbo.PurchaseOrderLines.[Amount Tax] AS [Line Tax],
                          dbo.PurchaseOrderLines.[Outlet Name] AS [Line Outlet Name], dbo.PurchaseOrderLines.[Required Date], dbo.ItemDetails.Brand, dbo.ItemDetails.Description, dbo.ItemDetails.DescriptionLong, dbo.ItemDetails.[Standard Cost], 
                         dbo.ItemDetails.Class, dbo.ItemDetails.Type, dbo.ItemDetails.Cost, dbo.ItemDetails.LowestPrice, dbo.ItemDetails.WeightedAverageCost, dbo.ItemDetails.LastReceiptDate, dbo.ItemDetails.LicenseCost, 
                         dbo.ItemDetails.[Retail Price], dbo.ItemDetails.[Trade Price], dbo.ItemDetails.[Cost Price], dbo.ItemDetails.[Average Cost], dbo.ItemDetails.ItemType, dbo.ItemDetails.[Item Group], dbo.PurchaseOrderHeaders.Currency, 
                         dbo.ItemDetails.TagPrice, dbo.PurchaseOrderLines.[Vendor Name], dbo.PurchaseOrderLines.[Vendor Code], dbo.ItemDetails.Group01, dbo.ItemDetails.ItemDetailsGroup01, dbo.ItemDetails.Group02, 
                         dbo.ItemDetails.ItemDetailsGroup02, dbo.ItemDetails.Group03, dbo.ItemDetails.ItemDetailsGroup03, dbo.ItemDetails.Group04, dbo.ItemDetails.ItemDetailsGroup04, dbo.ItemDetails.Group05, 
                         dbo.ItemDetails.ItemDetailsGroup05, dbo.ItemDetails.Group06, dbo.ItemDetails.ItemDetailsGroup06, dbo.ItemDetails.Group07, dbo.ItemDetails.ItemDetailsGroup07, dbo.ItemDetails.Group08, 
                         dbo.ItemDetails.ItemDetailsGroup08, dbo.ItemDetails.Group09, dbo.ItemDetails.ItemDetailsGroup09, dbo.ItemDetails.Group10, dbo.ItemDetails.ItemDetailsGroup10, dbo.ItemDetails.Group11, 
                         dbo.ItemDetails.ItemDetailsGroup11
FROM            dbo.ItemDetails RIGHT OUTER JOIN
                         dbo.PurchaseOrderLines ON dbo.ItemDetails.ItemName = dbo.PurchaseOrderLines.ItemName LEFT OUTER JOIN
                         dbo.PurchaseOrderHeaders ON dbo.PurchaseOrderLines.[PO Number] = dbo.PurchaseOrderHeaders.[PO Number] AND dbo.PurchaseOrderLines.[Line Number] = dbo.PurchaseOrderHeaders.[Line Number]
GO

